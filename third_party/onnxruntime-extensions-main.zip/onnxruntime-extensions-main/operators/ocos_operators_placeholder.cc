// Empty file that ensures that the ocos_operators lib is created.
// Simplifies the setup when ORT is building with extensions and either
// ocos_oeprators or noexcp_operators have empty source lists.
