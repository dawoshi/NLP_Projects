
Model sources:

PyTorch Mobilenet v2: https://pytorch.org/hub/pytorch_vision_mobilenet_v2/
PyTorch Super Resolution: https://pytorch.org/tutorials/advanced/super_resolution_with_onnxruntime.html
Tensorflow Lite Mobilenet v2: https://tfhub.dev/iree/lite-model/mobilenet_v2_100_224/fp32/1
