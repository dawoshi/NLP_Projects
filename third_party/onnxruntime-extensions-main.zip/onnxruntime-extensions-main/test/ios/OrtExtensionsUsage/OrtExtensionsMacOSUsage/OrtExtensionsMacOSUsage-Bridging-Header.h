//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#import "OrtClient.h"

#import <onnxruntime.h>
#include <onnxruntime_extensions.h>
