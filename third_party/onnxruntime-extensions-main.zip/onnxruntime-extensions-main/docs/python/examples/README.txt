Gallery of examples
===================

.. toctree::
    :maxdepth: 1
