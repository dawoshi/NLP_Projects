# OnnxRuntime.Extensions NuGet Package

[ONNX Runtime Extensions](https://github.com/microsoft/onnxruntime-extensions) is a library of custom ONNX operators used for pre and post processing ONNX models.